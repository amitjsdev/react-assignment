import React, { Component } from 'react';
import './Switch.css';
export default class FormDataComponent extends Component {

    userData;

    constructor(props) {
        super(props);

        this.onChangeName = this.onChangeName.bind(this);
        this.onChangeDob = this.onChangeDob.bind(this);
        this.onChangeFatherName = this.onChangeFatherName.bind(this);
        this.onChangeDepartment = this.onChangeDepartment.bind(this);
        this.onChangeSalary = this.onChangeSalary.bind(this);
        this.onSubmit = this.onSubmit.bind(this);

        this.state = {
            name: '',
            dob: '',
            FatherName: '',
            Department: '',
            Salary: '',
            errorDob: '',
			isOn: true,
			disabled: false,
			fieldVal: true
        }
    }

 changeColor(){
        this.setState({isOn: !this.state.isOn })
        this.setState({disabled: !this.state.disabled })
        this.setState({fieldVal: !this.state.fieldVal })
    }
    // Form Events
    onChangeName(e) {
        this.setState({ name: e.target.value })
    }

    onChangeDob(e) {
		
		var q = new Date();
		var m = q.getMonth()+1;
		var d = q.getDate();
		var y = q.getFullYear();
		var date2 = new Date(y+'-'+m+'-'+d);
		var date1=new Date(e.target.value);
		var diffTime = Math.abs(date2 - date1);
		var diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
		var finalDate = Math.abs(Math.round(diffDays/365.25));
		console.log(finalDate);
		  if(finalDate < 18){
			this.setState({ errorDob: 'Invalid date of birth' })
			this.setState({ dob: '' })
		  }else{
			  this.setState({ dob: e.target.value })
			  this.setState({ errorDob: '' })
		 }

    }

    onChangeFatherName(e) {
        this.setState({ FatherName: e.target.value })
    }
	 onChangeDepartment(e) {
        this.setState({ Department: e.target.value })
    }
	 onChangeSalary(e) {
        this.setState({ Salary: e.target.value })
    }
    onSubmit(e) {
        e.preventDefault()
			//localStorage.setItem('user',JSON.stringify(this.state));
			var oldItems = [];
			var oldItems = JSON.parse(localStorage.getItem('user'));
			console.log(oldItems);
			oldItems.push(this.state);
			localStorage.setItem('user', JSON.stringify(oldItems)); 

        this.setState({
				name: '',
				dob: '',
				FatherName: '',
				Department: '',
				Salary: ''
        }) 
    }


    render() {
		 let btn_class = this.state.isOn ? "blackButton" : "greenButton";
		 let fieldDisabled = this.state.disabled ? "disabled" : false;
		 let fieldVal = this.state.fieldVal ? "showField" : "hideField";
		 let btn_class2 = "react-switch-label";
		 let field_class = "form-group";
        return (
            <div className="container">
			 <input
			 
			  onClick={this.changeColor.bind(this)}
        className="react-switch-checkbox"
        id={`react-switch-new`}
        type="checkbox"
      />
      <label
        className={[btn_class, btn_class2].join(" ")}
        htmlFor={`react-switch-new`}
      >
        <span className={`react-switch-button`} />
      </label>
                <form className={btn_class} onSubmit={this.onSubmit}>
                    <div className="form-group">
                        <label>Name</label>
                        <input type="text" className="form-control" value={this.state.name} onChange={this.onChangeName} maxLength="20" />
                    </div>
                    <div className="form-group">
                        <label>dob</label>
                        <input type="date" className="form-control" value={this.state.dob} onChange={this.onChangeDob} />
						<span>{this.state.errorDob}</span>
                    </div>
                    <div className="form-group">
                        <label>Father Name</label>
                        <input type="text" className="form-control" value={this.state.FatherName} onChange={this.onChangeFatherName} />
                    </div>
					 <div className="form-group">
                        <label>Department</label>
                        <input type="text"  disabled = {fieldDisabled} className="form-control" value={this.state.Department} onChange={this.onChangeDepartment} />
                    </div>
					<div className={[field_class, fieldVal].join(" ")}>
                        <label>Salary</label>
                        <input type="number" className="form-control" value={this.state.Salary} onChange={this.onChangeSalary} />
                    </div>
                    <button type="submit" className="btn btn-primary btn-block">Submit</button>
                </form>
            </div>
        )
    }
}