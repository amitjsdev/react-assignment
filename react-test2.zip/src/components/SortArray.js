import React from 'react';

const SortArray = () => {
	const users = JSON.parse(localStorage.getItem('user'));
	const object = localStorage.getItem('user');

	var names = [];
	var rpeatedValues = [];

var result_val = [];
var result_val = [1, 2, -2, 4, 5, 4, 7, 8, 7, 7, 71, 3, 6];


function getDuplicateArrayElements(arra1) {
        var object = {};
        var result = [];

        arra1.forEach(function (item) {
          if(!object[item])
              object[item] = 0;
            object[item] += 1;
        })

        for (var prop in object) {
           if(object[prop] >= 2) {
               result.push(prop);
           }
        }

        return result;

    }

var duplicateColors= getDuplicateArrayElements(result_val); 
console.log(duplicateColors);

let numbers = [0, 1 , 2, 3, 10, 20, 30 ,5 ];
numbers.sort( function( a , b){
    if(a > b) return 1;
    if(a < b) return -1;
    return 0;
});

console.log(numbers);

  
  return (
    <>
	<div>All users List</div>
     {users.map(user => (
        <div  style={{ margin: '30px' }}>
          <div>{`name: ${user.name}`}</div>
          <div>{`dob: ${user.dob}`}</div>
          <div>{`FatherName: ${user.FatherName}`}</div>
          <div>{`Department: ${user.Department}`}</div>
          <div>{`Salary: ${user.Salary}`}</div>`
        </div>
      ))}
	  <div>Duplicate values: {duplicateColors}</div>
		<div>
		 {numbers.map(number => (
        <div  style={{ margin: '30px' }}>
          <div>{`Sort Number: ${number}`}</div>
        </div>
      ))}
	  </div>
	  
    </>
  );
};

export default SortArray;