import React, { Component } from 'react';
import {
  BrowserRouter as Router,
  Redirect,
  Switch,
  Route,
} from 'react-router-dom';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import './App.css';

import FormDataComponent from './components/FormDataComponent';
import SortArray from './components/SortArray';



class App extends Component {
  render() {
    return (
	<Router>  
     <div> 
	  <Switch>
	    <Route exact path="/" component={FormDataComponent} />
        <Route exact path="/sort" component={SortArray} />
		<Redirect to="/" />
      </Switch>
      </div>  
  </Router> 
    );
  }
}

export default App;